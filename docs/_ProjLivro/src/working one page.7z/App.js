import React, { Component } from 'react'


class App extends Component {

  // funcao remover caracter
  removeCharacter = index => {
    const { characters } = this.state

    this.setState({
      characters: characters.filter((character, i) => {
        return i !== index
      }),
    })
  };

  // estado inicial da app
  state = {
    characters: [
            {
              name: 'Charlie',
              job: 'Janitor',
            },
            {
              name: 'Mac',
              job: 'Bouncer',
            },
            {
              name: 'Dee',
              job: 'Aspring actress',
            },
            {
              name: 'Dennis',
              job: 'Bartender',
            },
          ],
  };

  // comeca a renderizar
  render() {


    const { characters } = this.state
    return (
      <div className="container">
        <Table characterData={characters} removeCharacter={this.removeCharacter} />
      </div>
    )
  };

};




class Table extends Component {
  constructor() {
    super()
    this.state = {tmp: 1};
  }

  


  render() {
      const { characterData, removeCharacter } = this.props




      return (
          <table>
              {/* titulo */}
              <thead>
                  <tr>
                      <th>Name</th>
                      <th>Job</th>
                      <th>botao</th>
                  </tr>
              </thead>

              {/* body */}
              <TableBody characterData={characterData} removeCharacter={removeCharacter} />
              
              
          </table>
      )
  }
}



const TableBody = props => {
  const rows = props.characterData.map((row, index) => {
      return (
          <tr key={index}>
              <td>{row.name}</td>
              <td>{row.job}</td>
              <td>
                  <button onClick={() => props.removeCharacter(index)}>Delete</button>
              </td>
          </tr>
      )
  })

  return <tbody>{rows}</tbody>
}





export default App;